import './App.css';
import Exam from './Exam'; 

function App() {
  return (
    <div>
      <Exam></Exam>
    </div>
  );
}

export default App;
