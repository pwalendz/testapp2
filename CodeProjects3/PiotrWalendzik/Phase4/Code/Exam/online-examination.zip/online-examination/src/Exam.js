import axios from "axios";
import { useEffect, useState } from "react";
import "./App.css";

function Exam() {
  let [questions, setQuestions] = useState([]);
  let [answers, setAnswers] = useState([]);
  let [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  let [selectedAnswer, setSelectedAnswer] = useState("");
  let [userAnswers, setUserAnswers] = useState([]);
  let [score, setScore] = useState(0);
  let [showResults, setShowResults] = useState(false);
  let [validationError, setValidationError] = useState("");

  useEffect(() => {
    axios
      .get("http://localhost:3000/questions")
      .then((result) => {
        setQuestions(result.data);
      })
      .catch((error) => {
        console.log(error);
      });

    axios
      .get("http://localhost:3000/answers")
      .then((result) => {
        setAnswers(result.data);
      })
      .catch((error) => {
        console.log(error);
      });
  }, []);

  let getSelectedAns = function (event) {
    setSelectedAnswer(event.target.value);
  };

  let submitAnswer = function () {
    if (!selectedAnswer) {
      setValidationError("Please select an option");
      return;
    }

    let userScore = score;

    if (selectedAnswer === String(answers[currentQuestionIndex].correctAns)) {
      userScore++;
    }

    setScore(userScore);

    setUserAnswers((prevAnswers) => [
      ...prevAnswers,
      { qid: questions[currentQuestionIndex].qid, answer: selectedAnswer },
    ]);

    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex((prevIndex) => prevIndex + 1);
    } else {
      setShowResults(true);
    }

    setSelectedAnswer("");
    setValidationError("");
  };

  let restartTest = function () {
    setCurrentQuestionIndex(0);
    setSelectedAnswer("");
    setScore(0);
    setShowResults(false);
    setUserAnswers([]);
  };

  let reviewAnswers = function () {
    return questions.map((question) => {
      let userAnswer = userAnswers.find((answer) => answer.qid === question.qid);
      let isCorrect =
        userAnswer &&
        userAnswer.answer === String(
          answers.find((ans) => ans.qid === question.qid).correctAns
        );

      return (
        <div key={question.qid}className={isCorrect ? "correct-answer" : "incorrect-answer"}>
          {question.qid}) {question.question}?<br/>
          Your Answer: {userAnswer ? userAnswer.answer : "Not answered"}<br/>
          Correct Answer: {answers.find((ans) => ans.qid === question.qid).correctAns}<br/>
          {isCorrect ? " Correct" : " Incorrect"}
          <hr />
        </div>
      );
    });
  };

  let question = questions[currentQuestionIndex];

  return (
    <div className="exam-container">
      <h2>Online Examination</h2>
      {!showResults ? (
        <div>
          {currentQuestionIndex < questions.length ? (
            <div>
              {question.qid}) {question.question}? <br />
              <label>
                <input
                  type="radio"
                  name={question.qid}
                  value={question.ans1}
                  checked={selectedAnswer === question.ans1}
                  onChange={getSelectedAns}
                />
                {question.ans1}
              </label>
              <br />
              <label>
                <input
                  type="radio"
                  name={question.qid}
                  value={question.ans2}
                  checked={selectedAnswer === question.ans2}
                  onChange={getSelectedAns}
                />
                {question.ans2}
              </label>
              <br />
              <label>
                <input
                  type="radio"
                  name={question.qid}
                  value={question.ans3}
                  checked={selectedAnswer === question.ans3}
                  onChange={getSelectedAns}
                />
                {question.ans3}
              </label>
              <br />
              <label>
                <input
                  type="radio"
                  name={question.qid}
                  value={question.ans4}
                  checked={selectedAnswer === question.ans4}
                  onChange={getSelectedAns}
                />
                {question.ans4}
              </label>
              <br />
              {validationError && <p className="error-message">{validationError}</p>}
              <button onClick={submitAnswer}>Submit</button>
            </div>
          ) : (
            <div>
              <h3>Results</h3>
              <p>Correct Answers: {score}</p>
              <button onClick={restartTest}>Try Again</button>
              <h3>Review Answers</h3>
  <div className="review-answers">{reviewAnswers()}</div>
            </div>
          )}
        </div>
      ) : (
        <div>
          <h3>Results</h3>
          <p>Correct Answers: {score}</p>
          <button onClick={restartTest}>Try Again</button>
          <h3>Review Answers</h3>
  <div className="review-answers">{reviewAnswers()}</div>
        </div>
      )}
    </div>
  );
}

export default Exam;
