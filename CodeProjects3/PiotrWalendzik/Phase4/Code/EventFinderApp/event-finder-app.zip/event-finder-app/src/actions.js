import { DELETE_EVENT, ADD_EVENT } from './actionTypes';

export const deleteEvent = (eventId) => {
  return {
    type: DELETE_EVENT,
    payload: eventId,
  };
};

export const addEvent = (eventName, eventDescription) => {
    return {
      type: ADD_EVENT,
      payload: { name: eventName, description: eventDescription },
    };
  };