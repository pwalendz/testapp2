import { v4 as uuidv4 } from 'uuid';

const initialState = {
    events: [],
  };
  
  function reducer(state = initialState, action) {
    switch (action.type) {
      case "LOAD_EVENTS":
        return {
          ...state,
          events: action.payload,
        };
      case "DELETE_EVENT":
        const updatedEvents = state.events.filter(
          (event) => event.id !== action.payload
        );
        return {
          ...state,
          events: updatedEvents,
        };

        case "ADD_EVENT":
      const newEvent = {
        id: uuidv4(), // Generate a unique ID using uuidv4()
        name: action.payload.name,
        description: action.payload.description,
      };
      return {
        ...state,
        events: [...state.events, newEvent],
      };


      default:
        return state;
    }
  }
  
  export default reducer;