import { useState } from 'react';
import {useSelector, useDispatch } from 'react-redux';
import { deleteEvent, addEvent } from './actions';

function SearchEvents(){
    const [eventname, setEventName] = useState('');
    const events = useSelector((state) => state.events);
    const [searchResults, setSearchResults] = useState([]);
    const dispatch = useDispatch();
  
    const searchEvent = function () {
        const lowercaseEventName = eventname.toLowerCase();
  const results = events.filter((e) =>
    e.name.toLowerCase().includes(lowercaseEventName)
  );
        setSearchResults(results);
    };

    const handleDeleteEvent = (eventId) => {
        dispatch(deleteEvent(eventId));
        setSearchResults(searchResults.filter((result) => result.id !== eventId));
      };

      const handleAddEvent = (event) => {
        event.preventDefault();
        const eventName = event.target.elements.eventName.value;
        const eventDescription = event.target.elements.eventDescription.value;
        if (eventName.trim() === '' || eventDescription.trim() === '') {
            // Show an error message or handle the validation error
            return;
          }
        dispatch(addEvent(eventName, eventDescription));
        const updatedEvents = [...events, { name: eventName, description: eventDescription }];
  setSearchResults(updatedEvents.filter((e) => e.name.includes(eventname)));
        event.target.reset();
      };

    return(
        <div className="container">
            <h2>Search Event</h2>
            
            <div className="row g-3">
    
        <div class="input-group justify-content-center">
        <div class="col-5">
            <input type="search" class="form-control rounded" placeholder="Search" onChange={
                (event)=>setEventName(event.target.value)
            } /></div>  
            <div class="col-auto">
            <input type="button" class="btn btn-primary"
            value="search" onClick={searchEvent}/>
            
            </div>
            </div>
    
            <div>
        <h2>Search Results</h2>
        {searchResults.length === 0 ? (
          <p>No results found.</p>
        ) : (
            <table className="table table-sm">
            <thead>
              <tr>
                <th>Name</th>
                <th>Description</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
            {searchResults.map((result) => (
              <tr key={result.id}><td className="column-width">{result.name}</td> <td className="column-width">{result.description}</td>
              <td><button onClick={() => handleDeleteEvent(result.id)} class="btn btn-primary">
                  Delete
                </button>
                </td>
                </tr>
            ))}
          </tbody>
</table>
        )}
      </div>
      </div>
      <div></div>
        <h2>Add New Event</h2>
        <div class="input-group justify-content-center">
        <form onSubmit={handleAddEvent} class="row g-3">
        <div class="col-auto">
          <input class="form-control rounded" type="text" name="eventName" placeholder="Event Name" />
          </div>
          <div class="col-auto">
          <input class="form-control rounded"
            type="text"
            name="eventDescription"
            placeholder="Event Description"
          />
          </div>
          <div class="col-auto">
          <button type="submit" class="btn btn-primary">Add Event</button>
          </div>
        </form>
      </div>      
        </div>
    )
}
export default SearchEvents;