package com.service;

import java.util.List;

import com.dao.StudentDao;
import com.dao.SubjectDao;
import com.entity.Student;
import com.entity.Subject;

public class SubjectService {

	SubjectDao pd  = new SubjectDao();
	
	public String storeSubject(Subject subject) {
		if(pd.storeSubject(subject)>0) {
			return "Subject was added successfully";
		}else {
			return "Subject was NOT added";
		}
	}
	public List<Subject> findAllSubject() {
		return pd.findAllSubject();
	}
	public static List<Subject> getAllSubjects() {
		SubjectDao sd = new SubjectDao();
		return sd.findAllSubject();
	}
}