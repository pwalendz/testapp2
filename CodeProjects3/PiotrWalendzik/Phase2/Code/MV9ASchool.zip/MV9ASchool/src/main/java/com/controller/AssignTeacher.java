package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.ClassDao;
import com.dao.TeacherDao;
import com.entity.Classes;
import com.entity.Teacher;
import com.service.ClassService;
import com.service.TeacherService;

/**
 * Servlet implementation class AssignTeacher
 */
@WebServlet("/AssignTeacher")
public class AssignTeacher extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public AssignTeacher() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		List<Classes> classes = ClassService.getAllClasses();
		List<Teacher> teachers = TeacherService.getAllTeachers();
		
		
		request.setAttribute("classes", classes);
		request.setAttribute("teachers", teachers);
		
	
		request.getRequestDispatcher("assignTeacher.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw = response.getWriter();
		
		response.setContentType("text/html");
		
		int classId = Integer.parseInt(request.getParameter("class_id"));
		String teacherName = request.getParameter("teacher_name");
		
		TeacherDao teacherDao = new TeacherDao();
		Teacher teacher = teacherDao.findByTeacherName(teacherName);
		
		if (teacher == null) {
			response.getWriter().println("Teacher not found. Make sure that you are spelling the name as found in the View Teachers link.");
			return;
		}
		
		ClassDao classDao = new ClassDao();
		Classes classes = classDao.findClassById(classId);
		
		if (classes == null) {
			response.getWriter().println("Class not found");
			return;
		}
		
		classes.setTeacher(teacher);
		classDao.updateClass(classes);
		
		pw.println("Teacher assigned to class successfully");

		RequestDispatcher rd = request.getRequestDispatcher("index.jsp");
		rd.include(request, response);
//		doGet(request, response);
}

}
