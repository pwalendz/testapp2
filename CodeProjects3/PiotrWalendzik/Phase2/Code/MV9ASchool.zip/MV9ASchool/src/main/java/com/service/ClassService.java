package com.service;

import java.util.List;

import com.dao.ClassDao;
import com.entity.Classes;
import com.entity.Subject;

public class ClassService {
	ClassDao pd  = new ClassDao();
	
	public String storeClass(Classes classes) {
		if(pd.storeClass(classes)>0) {
			return "Class was added successfully";
		}else {
			return "Class was NOT added";
		}
	}
	public List<Classes> findAllClass() {
		return pd.findAllClass();
	}
	public static List<Classes> getAllClasses() {
		ClassDao sd = new ClassDao();
	    return sd.getAllClasses();
	}
}