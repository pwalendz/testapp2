package com.service;

import java.util.List;

import com.dao.SubjectDao;
import com.dao.TeacherDao;
import com.entity.Subject;
import com.entity.Teacher;

public class TeacherService {
	TeacherDao pd  = new TeacherDao();
	
	public String storeTeacher(Teacher teacher) {
		if(pd.storeTeacher(teacher)>0) {
			return "Teacher was added successfully";
		}else {
			return "Teacher was NOT added";
		}
	}
	public List<Teacher> findAllTeacher() {
		return pd.findAllTeacher();
	}
	public static List<Teacher> getAllTeachers() {
		TeacherDao sd = new TeacherDao();
		return sd.findAllTeacher();
	}
}
