package com.service;

import java.util.List;

import com.dao.StudentDao;
import com.entity.Classes;
import com.entity.Student;

public class StudentService {
	StudentDao pd  = new StudentDao();
	
	public String storeStudent(Student student) {
		if(pd.storeStudent(student)>0) {
			return "Student was added successfully";
		}else {
			return "Student was NOT added";
		}
	}
	public List<Student> findAllStudent() {
		return pd.findAllStudent();
	}
	public static List<Student> getAllStudents() {
		StudentDao sd = new StudentDao();
		return sd.findAllStudent();
	}
}