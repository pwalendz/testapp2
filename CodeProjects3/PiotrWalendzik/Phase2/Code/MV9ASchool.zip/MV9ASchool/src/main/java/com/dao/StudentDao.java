package com.dao;

import java.util.List;

import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.entity.Classes;
import com.entity.Student;
import com.entity.Teacher;
import com.resource.DbResource;

public class StudentDao {

	public int storeStudent(Student student) {
		SessionFactory sf = DbResource.getSessionFactory();
		Session session = sf.openSession();
		Transaction tran = session.getTransaction();
		tran.begin();
			session.save(student);
		tran.commit();		
		return 1;
	}
	public List<Student> findAllStudent() {
		SessionFactory sf = DbResource.getSessionFactory();
		Session session = sf.openSession();
		TypedQuery tq = session.createQuery("from Student");
		List<Student> listOfStudent = tq.getResultList();
		return listOfStudent;
	}
	public Student findByStudentName(String name) {
	    SessionFactory sf = DbResource.getSessionFactory();
	    Session session = sf.openSession();
	    TypedQuery<Student> query = session.createQuery("from Student where student_name=:student_name");
	    query.setParameter("student_name", name);
	    List<Student> students = query.getResultList();
	    if (students.isEmpty()) {
	        return null;
	    } else {
	        return students.get(0);
	    }
	}
	public void updateStudent(Student students) {
	    SessionFactory sf = DbResource.getSessionFactory();
	    Session session = sf.openSession();
	    Transaction tran = session.getTransaction();
	    tran.begin();
	    session.update(students);
	    tran.commit();
	}
}