package com.dao;

import java.util.List;

import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.entity.Classes;
import com.resource.DbResource;

public class ClassDao {
	public int storeClass(Classes classes) {
		SessionFactory sf = DbResource.getSessionFactory();
		Session session = sf.openSession();
		Transaction tran = session.getTransaction();
		tran.begin();
			session.save(classes);
		tran.commit();		
		return 1;
	}
	public List<Classes> findAllClass() {
		SessionFactory sf = DbResource.getSessionFactory();
		Session session = sf.openSession();
		TypedQuery tq = session.createQuery("from Classes");
		List<Classes> listOfClass = tq.getResultList();
		return listOfClass;
	}
	public Classes findClassById(int classId) {
	    SessionFactory sf = DbResource.getSessionFactory();
	    Session session = sf.openSession();
	    try {
	        Classes classes = session.get(Classes.class, classId);
	        return classes;
	    } finally {
	        session.close();
	    }
	}

	public void updateClass(Classes classes) {
	    SessionFactory sf = DbResource.getSessionFactory();
	    Session session = sf.openSession();
	    Transaction tran = session.getTransaction();
	    tran.begin();
	    session.update(classes);
	    tran.commit();
	}
	public List<Classes> getAllClasses() {
	    SessionFactory sf = DbResource.getSessionFactory();
	    Session session = sf.openSession();
	    TypedQuery<Classes> tq = session.createQuery("select distinct c from Classes c", Classes.class);
	    List<Classes> classes = tq.getResultList();
	    return classes;
	}
}

