package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.entity.Classes;
import com.entity.Subject;
import com.entity.Teacher;
import com.service.ClassService;

/**
 * Servlet implementation class ClassController
 */
@WebServlet("/ClassController")
public class ClassController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ClassController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw = response.getWriter();
		response.setContentType("text/html");
		ClassService ps = new ClassService();
		List<Classes> listOfClass = ps.findAllClass();
		for (Classes cls : listOfClass) {
		    if (cls.getSubject() == null && cls.getTeacher() == null) {
		        Subject nullSubject = new Subject();
		        nullSubject.setSubject_name(" ");
		        cls.setSubject(nullSubject);

		        Teacher nullTeacher = new Teacher();
		        nullTeacher.setTeacher_name(" ");
		        cls.setTeacher(nullTeacher);
		    }
		    else if (cls.getSubject() == null) {
		        Subject nullSubject = new Subject();
		        nullSubject.setSubject_name(" ");
		        cls.setSubject(nullSubject);
		    }
		    else if (cls.getTeacher() == null) {
		        Teacher nullTeacher = new Teacher();
		        nullTeacher.setTeacher_name(" ");
		        cls.setTeacher(nullTeacher);
		    }
		}
		request.setAttribute("listOfClass", listOfClass);
		RequestDispatcher rd = request.getRequestDispatcher("viewClass.jsp");
		rd.include(request, response);
		
		}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw = response.getWriter();
		
		response.setContentType("text/html");
		
		String className = request.getParameter("ClassName");
		
		Classes p = new Classes();
		p.setClass_name(className);
	
		ClassService ps = new ClassService();
		String result  = ps.storeClass(p);
		
		pw.println(result);
		
		RequestDispatcher rd = request.getRequestDispatcher("index.jsp");
		rd.include(request, response);
		doGet(request, response);
	}

}
