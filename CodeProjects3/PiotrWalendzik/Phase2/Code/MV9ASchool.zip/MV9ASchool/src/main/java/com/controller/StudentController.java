package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.entity.Classes;
import com.entity.Student;
import com.entity.Subject;
import com.entity.Teacher;
import com.service.StudentService;

/**
 * Servlet implementation class StudentController
 */
@WebServlet("/StudentController")
public class StudentController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public StudentController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw = response.getWriter();
		response.setContentType("text/html");
		StudentService ps = new StudentService();
		List<Student> listOfStudent = ps.findAllStudent();
		for (Student student : listOfStudent) {
		    if (student.getClassObj() == null) {
		        Classes nullClass = new Classes();
		        nullClass.setClass_name(" ");
		        Subject nullSubject = new Subject();
		        nullSubject.setSubject_name(" ");
		        Teacher nullTeacher = new Teacher();
		        nullTeacher.setTeacher_name(" ");
		        nullClass.setSubject(nullSubject);
		        nullClass.setTeacher(nullTeacher);
		        student.setClassObj(nullClass);
		    } else {
		        if (student.getClassObj().getSubject() == null) {
		            Subject nullSubject = new Subject();
		            nullSubject.setSubject_name(" ");
		            student.getClassObj().setSubject(nullSubject);
		        }
		        if (student.getClassObj().getTeacher() == null) {
		            Teacher nullTeacher = new Teacher();
		            nullTeacher.setTeacher_name(" ");
		            student.getClassObj().setTeacher(nullTeacher);
		        }
		    }
		}
		request.setAttribute("listOfStudent", listOfStudent);
		RequestDispatcher rd = request.getRequestDispatcher("viewStudent.jsp");
		rd.include(request, response);
		
		}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw = response.getWriter();
		
		response.setContentType("text/html");
		
		String studentName = request.getParameter("StudentName");
		
		Student p = new Student();
		p.setStudent_name(studentName);
	
		StudentService ps = new StudentService();
		String result  = ps.storeStudent(p);
		
		pw.println(result);
		
		RequestDispatcher rd = request.getRequestDispatcher("index.jsp");
		rd.include(request, response);
		doGet(request, response);
	}

}
