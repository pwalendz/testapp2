package com.dao;

import java.util.List;

import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.entity.Subject;
import com.resource.DbResource;

public class SubjectDao {

	public int storeSubject(Subject subject) {
		SessionFactory sf = DbResource.getSessionFactory();
		Session session = sf.openSession();
		Transaction tran = session.getTransaction();
		tran.begin();
			session.save(subject);
		tran.commit();		
		return 1;
	}
	public List<Subject> findAllSubject() {
		SessionFactory sf = DbResource.getSessionFactory();
		Session session = sf.openSession();
		TypedQuery tq = session.createQuery("from Subject");
		List<Subject> listOfSubject = tq.getResultList();
		return listOfSubject;
	}
	public Subject findBySubjectName(String name) {
	    SessionFactory sf = DbResource.getSessionFactory();
	    Session session = sf.openSession();
	    TypedQuery<Subject> query = session.createQuery("from Subject where subject_name=:subject_name");
	    query.setParameter("subject_name", name);
	    List<Subject> subjects = query.getResultList();
	    if (subjects.isEmpty()) {
	        return null;
	    } else {
	        return subjects.get(0);
	    }
	}
}
